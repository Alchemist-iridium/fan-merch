# Installation and activation
- create a virtual environment first
```
python3 -m venv .venv
```
- install the packages
```
pip install uuid6 flask flask-sqlalchemy werkzeug pyotp requests
```
- activate virtual environment
```
source .venv/bin/activate 
```
- run main.py
```
python3 main.py
```


# Roles , data and webpage link

## Customer and Artist
- home page http://127.0.0.1:5000
- add new user:
	- Login/Sign Up

## Admins
- home page [http://localhost:5000/admin/admin_login](http://localhost:5000/admin/admin_login)
- add new user:
	- add_admin.py

	```
	python3 add_admin.py 
	```

	 - add through info admin dashboard - add new admin
		- add warehouse before adding the delivery admin in "Manage Warehouses"
		- the default main_production_species of the order management admin is general, which can be modified in "Modify Production Species of Order Management Admin"

![[截屏2025-02-23 16.10.18.png]]
![[截屏2025-02-23 17.24.35.png]]
## Region, Warehouse, Mapping and Cost Grid (must be set up!)

### Region, related to taxes

![[截屏2025-02-23 18.52.57.png]]
### Warehouse, where the items stored

![[截屏2025-02-23 18.55.02.png]]
### Mapping
- region-warehouse relationship: many to one
- one region can only have one warehouse
![[截屏2025-02-23 18.55.52.png]]
### Delivery Cost Grid
- postal code is optional, default is choosing the N/A value
![[截屏2025-02-23 20.19.35.png]]
# workflow
## Artwork upload

- Roles: Artist and Artwork Approval Admin
### 1: Artist "Submit New Artwork"
![[截屏2025-02-23 16.03.33.png]]

![[截屏2025-02-23 16.04.32.png]]
![[截屏2025-02-23 16.05.12.png]]


### 2: Artwork Approval Admin "Approve Artwork" & "Artwork Update"
#### Approve Artwork
##### Admin Dashboard, pick or search & pick to workspace
![[截屏2025-02-23 16.36.25.png]]

- search hard tag & pick
![[截屏2025-02-23 16.37.40.png]]

##### Artwork Approval Workspace

![[截屏2025-02-23 16.38.31.png]]

- After the ip holder approves the artwork to be a product, approve

![[截屏2025-02-23 16.39.15.png]]

- Disapprove, submit reason

![[截屏2025-02-23 16.42.33.png]]

##### Artist Dashboard, view result
![[截屏2025-02-23 16.42.58.png]]![[截屏2025-02-23 16.43.46.png]]
#### Artwork Update

##### Artist Dashboard, update artwork information

![[截屏2025-02-23 16.44.22.png]]
##### Admin Dashboard, pick or search & pick to workspace

![[截屏2025-02-23 17.04.13.png]]
##### Artwork Update Workspace

![[截屏2025-02-23 16.58.30.png]]

- disapprove reason, in notification

![[截屏2025-02-23 16.59.19.png]]


## Product Upload

- Roles: Artist and Product Approval Admin
### 1: Artist "Submit Product for Artwork"

![[截屏2025-02-23 17.14.50.png]]![[截屏2025-02-23 17.15.39.png]]

### 2: Product Approval Admin "Approve Product" & "Assign Order Management Admin"

#### Approve Product & Assign Order Management Admin

##### Admin Dashboard, pick or search & pick to approval workspace

![[截屏2025-02-23 17.19.12.png]]

##### Workspace

![[截屏2025-02-23 17.19.33.png]]

###### If approve, assign order management admin to manage the production of the product

![[截屏2025-02-23 17.25.37.png]]![[截屏2025-02-23 17.25.56.png]]
###### If disapprove, then submit the reason

![[截屏2025-02-23 17.27.33.png]]

### 3: Artist "View the Result"

![[截屏2025-02-23 17.33.25.png]]
#### Approved product - Product Management

![[截屏2025-02-23 17.34.30.png]]
#### Disapproved product - reason

![[截屏2025-02-23 17.33.41.png]]



## Production Round management

- Roles: Artist and Order Management Admin
### 1: Initialization of a Production Round
#### Artist: Manage Production Round Initialization Control
- who to initialize a production round?
- default: artist, can switch to order management admin
##### Artist control
![[截屏2025-02-23 17.41.06.png]]
![[截屏2025-02-23 17.41.16.png]]
![[截屏2025-02-23 17.42.58.png]]
##### Admin control

![[截屏2025-02-23 17.43.16.png]]![[截屏2025-02-23 17.43.34.png]]

### 2: Order Management Admin "Product Management" & "Production Round Management"

#### Product Management

- content and display setting are separated

![[截屏2025-02-23 17.57.35.png]]![[截屏2025-02-23 17.57.50.png]]

#### Production Round Management
- price
- minimum quantity and maximum date: if not reaching the minimum quantity before the maximum date, the production round shall be abandoned and refunded. Can choose to negotiate with a different price & quantity limit or not initialize in a while.
-  delivery point (related to delivery cost)

![[截屏2025-02-23 17.47.13.png]]

- co-fund stage incentives: when quantity reaches certain stage, give gift

![[截屏2025-02-23 17.47.30.png]]

#### Result

![[截屏2025-02-23 18.02.23.png]]![[截屏2025-02-23 18.03.27.png]]![[截屏2025-02-23 18.03.40.png]]

### 3: product management control transfer
- Roles: between Order Management Admins, handled by Product Approval Admin
#### Order Management Admin: Product Management Transfer
![[截屏2025-02-23 18.07.39.png]]

#### Product Management Admin: Dashboard and Transfer Workspace

![[截屏2025-02-23 18.09.01.png]]
![[截屏2025-02-23 18.09.18.png]]
##### Approve Transfer

![[截屏2025-02-23 18.09.33.png]]![[截屏2025-02-23 18.11.43.png]]![[截屏2025-02-23 18.11.56.png]]
##### Disapprove Transfer

![[截屏2025-02-23 18.14.23.png]]![[截屏2025-02-23 18.14.46.png]]


## Purchase Item

- Roles: customer
### 1: Purchase: Login Required

![[截屏2025-02-23 18.20.23.png]]![[截屏2025-02-23 18.20.43.png]]
#### Artist public page
- information can be modified on artist dashboard
![[截屏2025-02-23 18.21.47.png]]

#### Artwork Page

![[截屏2025-02-23 18.22.41.png]]
![[截屏2025-02-23 18.20.53.png]]

#### Product Page
![[截屏2025-02-23 18.23.58.png]]

![[截屏2025-02-23 18.24.20.png]]

#### Add to cart
##### If not login, redirect page
![[截屏2025-02-23 18.25.12.png]]
##### If login, view cart, dynamic change
![[截屏2025-02-23 18.26.35.png]]![[截屏2025-02-23 18.26.46.png]]![[截屏2025-02-23 18.28.53.png]]

#### Select to checkout
- before checkout, make sure that the regions is set up in info admin dashboard -  region management, as they are related to tax!!

![[截屏2025-02-23 18.50.50.png]]

![[截屏2025-02-23 18.29.24.png]]![[截屏2025-02-23 18.29.34.png]]
#### Checkout
- Right now only support wallet payment
- Tax is region based

![[截屏2025-02-23 18.58.07.png]]![[截屏2025-02-23 18.59.05.png]]
##### unpaid

![[截屏2025-02-23 18.59.56.png]]

- add fund to wallet

![[截屏2025-02-23 19.01.02.png]]

![[截屏2025-02-23 19.00.28.png]]

- view item orders, pay unpaid order

![[截屏2025-02-23 19.00.47.png]]![[截屏2025-02-23 19.01.56.png]]![[截屏2025-02-23 19.02.21.png]]![[截屏2025-02-23 19.03.06.png]]
##### paid

![[截屏2025-02-23 19.04.52.png]]![[截屏2025-02-23 19.05.30.png]]![[截屏2025-02-23 19.05.48.png]]
![[截屏2025-02-23 19.07.45.png]]

#### Item Management

![[截屏2025-02-23 19.06.11.png]]


### 2: Refund: full refund and partial refund
- full refund: stage = waiting of production round and item status = item, price+tax
- partial refund: stage = sampling of production round and item status = item, as the unit fixed cost is on making samples, partial refund + tax

![[截屏2025-02-23 19.23.55.png]]![[截屏2025-02-23 19.31.51.png]]![[截屏2025-02-23 19.32.09.png]]

partial refund in sample stage

![[截屏2025-02-23 19.33.01.png]]![[截屏2025-02-23 19.33.59.png]]![[截屏2025-02-23 19.34.26.png]]

## Warehouse receiving and distribution

- Role: Warehouse Admin and Order Management Admin

![[截屏2025-02-23 19.38.25.png]]


### Add and Search Warehouse Storage ()

![[截屏2025-02-23 20.04.23.png]]

#### Search, available/occupied
![[截屏2025-02-23 20.09.04.png]]
![[截屏2025-02-23 20.09.42.png]]
![[截屏2025-02-23 20.10.07.png]]


### Check flaw and confirm product
- from the factory to the warehouse
- only after accept can the production round enters stocking, which allows the customer to place delivery order

![[截屏2025-02-23 19.39.12.png]]![[截屏2025-02-23 20.02.33.png]]![[截屏2025-02-23 20.03.09.png]]![[截屏2025-02-23 20.08.19.png]]![[截屏2025-02-23 20.11.43.png]]![[截屏2025-02-23 20.11.55.png]]
## Places Delivery Order

### 1: Customer, item management/waiting for delivery
- select a region and create a delivery order
![[截屏2025-02-23 20.16.27.png]]![[截屏2025-02-23 20.16.54.png]]![[截屏2025-02-23 20.21.05.png]]![[截屏2025-02-23 20.21.16.png]]![[截屏2025-02-23 20.21.26.png]]![[截屏2025-02-23 20.21.36.png]]![[截屏2025-02-23 20.21.43.png]]![[截屏2025-02-23 20.22.00.png]]![[截屏2025-02-23 20.22.08.png]]![[截屏2025-02-23 20.22.18.png]]

### 2: Delivery Admin, process the delivery order
##### Pick delivery order
![[截屏2025-02-23 20.26.59.png]]
#### Receipt for warehouse retrieval (can process multiple order)

![[截屏2025-02-23 20.28.15.png]]![[截屏2025-02-23 20.28.26.png]]![[截屏2025-02-23 20.28.38.png]]

#### Check the storage space to deduct the quantity

![[截屏2025-02-23 20.29.56.png]]![[截屏2025-02-23 20.30.16.png]]

- When storage reaches 0 or very little (can change to different size of storage), ask Warehouse Admin to update/delete it

![[截屏2025-02-23 20.31.13.png]]

![[截屏2025-02-23 20.33.35.png]]

![[截屏2025-02-23 20.31.42.png]]

### 3: Customer, confirm receive package
![[截屏2025-02-23 20.34.42.png]]![[截屏2025-02-23 20.34.57.png]]![[截屏2025-02-23 20.35.06.png]]![[截屏2025-02-23 20.35.16.png]]![[截屏2025-02-23 20.35.33.png]]
- item transfers from in_process to delivered, completed
![[截屏2025-02-23 20.35.53.png]]


## Abandon stage, all refund


![[截屏2025-02-23 20.39.54.png]]![[截屏2025-02-23 20.40.31.png]]
- Not reaching minimum production size, abandon
![[截屏2025-02-23 20.41.05.png]]![[截屏2025-02-23 20.41.45.png]]

![[截屏2025-02-23 20.42.32.png]]